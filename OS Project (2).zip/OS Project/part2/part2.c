#define _XOPEN_SOURCE 600
#include <semaphore.h>
#include <omp.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>

int student_count=0;
pthread_barrier_t room;
int students=0;
int room_max =0;
omp_lock_t mutex, mutex2;
sem_t office_capacity;

void AnswerStart(int id){
  printf("Professor starts to answer question for student %d. \n",id);
}

void AnswerDone(int id){
  printf("Professor is done with answer for student %d.\n", id);
}

void questionDone(int id){
  printf("Student %d is satisfied.\n", id);
}

void questionStart(int id){
  printf("Student %d asks a question.\n",id);
}

void enterOffice(int id){
  printf("Student %d enters the office.\n", id);
}

void leaveOffice(int id){
  printf("Student %d leaves the office.\n", id);

}

void professor(int id){
  AnswerStart(id);
  AnswerDone(id);
}

int main(int argc, char *argv[]){
  if(argc < 3 ||argc > 3){
    printf("incorrect # of parameters");
    return -1;
  }
  if(!isdigit((unsigned char)*argv[1]) || !isdigit((unsigned char)*argv[2])){
    printf("incorrect input");
    return -1;
  }
      int i;
      students = atoi(argv[1]);
      room_max = atoi(argv[2]);
      printf("\n%d student(s) will be visiting Professor X. His room size is %d.\n",students, room_max);
      omp_set_num_threads(students);
      omp_init_lock(&mutex);
      if(sem_init(&office_capacity, 0, room_max)){//checks the rooms capacity
        printf("Could not initialize a semaphore\n");
        return -1;
      }
      #pragma omp parallel num_threads(students)
      {
      #pragma omp for private(i) ordered schedule(dynamic)
      for(i=0;i<students;i++){
        int q;
        sem_wait(&office_capacity);//semaphore decrements office_capacity
        enterOffice(i);
	sleep(3);
        //printf("%d  %d\n",student_count, students);
        for(q = 0; q<i%4+1;q++){
          sleep(1*q);
	  omp_set_lock(&mutex);
          questionStart(i);
          professor(i);
          questionDone(i);
          omp_unset_lock(&mutex);
          }
          leaveOffice(i);
          sem_post(&office_capacity);//increments room capacity
      }  
     }
      omp_destroy_lock(&mutex);
      return 0;
}
