Description:
This note describes how to run the OS Project Programs in detail



To compile Part2:
1. Open Terminal and go to 'OS Project/Part2' directory
2. Type 'make all' to compile part2 code

To run Part2 output: (after compiling)
1. Type './part2 X Y' to run output of Part2 (X represent the number of students and Y the room size)


Thanks,

Groups.