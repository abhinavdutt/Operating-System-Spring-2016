Description:
This note describes how to run the OS Project Programs in detail



To compile Part1:
1. Open Terminal and go to 'OS Project/Part1' directory
2. Type 'make all' to compile part1_1 and part1_2 codes

To run Part1 output: (after compiling)
1. Type './part1_1 X' to run output of Part1 of Program 1_1 (X represent the number of threads)
2. Type './part1_2 X' to run output of Part1 of Program 1_2 (X represent the number of threads)


Thanks,

Groups.